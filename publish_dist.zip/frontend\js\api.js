// Configuração simples de acesso à API
// Se estiver rodando em servidor separado (ex: Live Server na porta 5500 ou arquivo local),
// aponta para o back-end .NET na porta 5298. Se servido junto à API, usa o caminho relativo.
const API_BASE_URL = (window.location.port === '5298') ? '' : 'http://localhost:5298';

/**
 * Consulta a lista de cursos com filtros opcionais
 * @param {Object} filters { search, category, modality, status }
 */
async function fetchCourses(filters = {}) {
  const params = new URLSearchParams();
  if (filters.search) params.set('search', filters.search);
  if (filters.category) params.set('category', filters.category);
  if (filters.modality) params.set('modality', filters.modality);
  if (filters.status) params.set('status', filters.status);

  const query = params.toString();
  const url = `${API_BASE_URL}/api/courses${query ? '?' + query : ''}`;

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Erro ${response.status}: Não foi possível carregar os cursos.`);
  }
  return await response.json();
}

/**
 * Consulta os detalhes completos de um curso pelo ID
 * @param {number|string} id
 */
async function fetchCourseById(id) {
  const url = `${API_BASE_URL}/api/courses/${id}`;
  const response = await fetch(url);
  if (!response.ok) {
    if (response.status === 404) {
      throw new Error('Curso não encontrado.');
    }
    throw new Error(`Erro ${response.status}: Falha ao buscar detalhes do curso.`);
  }
  return await response.json();
}

/**
 * Retorna o ícone e a classe de badge correspondente à categoria
 */
function getCategoryInfo(category) {
  const map = {
    'Matemática': {
      icon: 'assets/icons/icon-matematica-20px.svg',
      badgeClass: 'badge-matematica'
    },
    'Ciências da Natureza': {
      icon: 'assets/icons/icon-ciencias-natureza-20px.svg',
      badgeClass: 'badge-ciencias'
    },
    'Sustentabilidade': {
      icon: 'assets/icons/icon-sustentabilidade-20px.svg',
      badgeClass: 'badge-sustentabilidade'
    },
    'Linguagens': {
      icon: 'assets/icons/icon-linguagens-20px.svg',
      badgeClass: 'badge-linguagens'
    }
  };

  return map[category] || {
    icon: 'assets/icons/icon-matematica-20px.svg',
    badgeClass: 'badge-matematica'
  };
}

/**
 * Gera o HTML de um Card de Curso exatamente igual ao Figma
 */
function createCourseCardHTML(course) {
  const cat = getCategoryInfo(course.category);
  // Garante que o caminho da imagem seja relativo e correto
  let imgPath = course.imageUrl;
  if (imgPath && imgPath.startsWith('/')) {
    imgPath = imgPath.substring(1);
  }

  return `
    <article class="course-card" onclick="window.location.href='detalhes.html?id=${course.id}'" role="button" tabindex="0" aria-label="Ver detalhes do curso: ${course.fullName}">
      <div class="card-img-wrapper">
        <img src="${imgPath}" alt="" class="card-img" loading="lazy" />
        <div class="card-overlay"></div>
        <span class="badge-category ${cat.badgeClass}">
          <img src="${cat.icon}" alt="" aria-hidden="true" />
          ${course.category}
        </span>
      </div>
      <div class="card-body">
        <div>
          <h3 class="card-title">${course.fullName}</h3>
          <p class="card-desc">${course.description}</p>
        </div>
        <div class="card-meta">
          <span>${course.workloadHours} horas</span>
          <span>${course.modality}</span>
          <span class="card-status-pill">${course.status}</span>
        </div>
      </div>
    </article>
  `;
}
