// Gerenciamento da tela do AVA (ava.html - Flow 03)
document.addEventListener('DOMContentLoaded', async () => {
  const urlParams = new URLSearchParams(window.location.search);
  const courseId = urlParams.get('id') || '1';

  const titleEl = document.getElementById('ava-course-title');
  const modulesNav = document.getElementById('ava-modules-nav');
  const lessonTitleEl = document.getElementById('ava-lesson-title');
  const btnBackDetails = document.getElementById('btn-back-details');
  const btnComplete = document.getElementById('btn-complete-lesson');
  const progressPercent = document.getElementById('progress-percent');
  const progressFill = document.getElementById('progress-fill');

  let currentCourse = null;
  let isCompleted = false;

  btnBackDetails.href = `detalhes.html?id=${courseId}`;

  try {
    currentCourse = await fetchCourseById(courseId);
    titleEl.textContent = currentCourse.fullName;
    document.title = `${currentCourse.fullName} | AVA SESI`;

    renderNav(currentCourse.modules);
  } catch (err) {
    titleEl.textContent = 'Curso SESI';
  }

  function renderNav(modules) {
    if (!modules || modules.length === 0) {
      modulesNav.innerHTML = `
        <div class="ava-nav-section">
          <div class="ava-nav-title">Módulo 1: Introdução</div>
          <ul class="ava-lessons-nav">
            <li><a href="#" class="ava-lesson-link active">✓ Aula 01 - Apresentação</a></li>
          </ul>
        </div>
      `;
      return;
    }

    modulesNav.innerHTML = modules.map((mod, modIdx) => `
      <div class="ava-nav-section">
        <div class="ava-nav-title">Módulo ${modIdx + 1}: ${mod.title}</div>
        <ul class="ava-lessons-nav">
          ${(mod.lessons || []).map((l, lIdx) => {
            const isActive = modIdx === 0 && lIdx === 0;
            return `
              <li>
                <a href="#" class="ava-lesson-link ${isActive ? 'active' : ''}" data-title="${l.title}">
                  ${isActive ? '✓' : '○'} ${l.title}
                </a>
              </li>
            `;
          }).join('')}
        </ul>
      </div>
    `).join('');

    // Adiciona evento de clique nas aulas para alterar a aula ativa
    const links = modulesNav.querySelectorAll('.ava-lesson-link');
    links.forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        links.forEach(l => l.classList.remove('active'));
        link.classList.add('active');
        const title = link.getAttribute('data-title');
        if (title) {
          lessonTitleEl.textContent = title;
        }
      });
    });
  }

  // Interatividade do botão "Marcar aula como concluída"
  btnComplete.addEventListener('click', () => {
    isCompleted = !isCompleted;
    if (isCompleted) {
      progressPercent.textContent = '25% concluído';
      progressFill.style.width = '25%';
      btnComplete.textContent = 'Aula concluída ✓';
      btnComplete.style.backgroundColor = '#16a34a'; // verde sucesso
    } else {
      progressPercent.textContent = '10% concluído';
      progressFill.style.width = '10%';
      btnComplete.textContent = 'Marcar aula como concluída ✓';
      btnComplete.style.backgroundColor = '';
    }
  });
});
