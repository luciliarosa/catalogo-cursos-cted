// Lógica simples da Landing Page (index.html)
document.addEventListener('DOMContentLoaded', async () => {
  const carousel = document.getElementById('courses-carousel');
  const btnPrev = document.getElementById('btn-courses-prev');
  const btnNext = document.getElementById('btn-courses-next');

  // 1. Carregar os principais cursos da API
  try {
    const data = await fetchCourses();
    const courses = Array.isArray(data) ? data : (data?.items || []);
    if (courses.length > 0) {
      // Exibe os primeiros 6 cursos no carrossel
      const topCourses = courses.slice(0, 6);
      carousel.innerHTML = topCourses.map(course => createCourseCardHTML(course)).join('');
    } else {
      carousel.innerHTML = '<p class="state-desc" style="padding: 20px;">Nenhum curso disponível no momento.</p>';
    }
  } catch (error) {
    console.error('Erro ao buscar cursos:', error);
    carousel.innerHTML = `
      <div class="error-box" style="margin: 0 auto;">
        <p class="error-title">Erro ao carregar cursos</p>
        <p class="state-desc">Verifique se a API do back-end está em execução na porta 5298.</p>
      </div>
    `;
  }

  // 2. Controles de rolagem do carrossel de cursos
  if (btnPrev && btnNext && carousel) {
    btnPrev.addEventListener('click', () => {
      carousel.scrollBy({ left: -340, behavior: 'smooth' });
    });
    btnNext.addEventListener('click', () => {
      carousel.scrollBy({ left: 340, behavior: 'smooth' });
    });
  }

  // 3. Controles do carrossel de depoimentos
  const testCarousel = document.getElementById('testimonials-carousel');
  const btnTestPrev = document.getElementById('btn-test-prev');
  const btnTestNext = document.getElementById('btn-test-next');

  if (btnTestPrev && btnTestNext && testCarousel) {
    btnTestPrev.addEventListener('click', () => {
      testCarousel.scrollBy({ left: -330, behavior: 'smooth' });
    });
    btnTestNext.addEventListener('click', () => {
      testCarousel.scrollBy({ left: 330, behavior: 'smooth' });
    });
  }
});
