// Gerenciamento da página de Detalhes do Curso (detalhes.html)
document.addEventListener('DOMContentLoaded', async () => {
  const loadingState = document.getElementById('loading-state');
  const errorState = document.getElementById('error-state');
  const errorMessage = document.getElementById('error-message');
  const courseContent = document.getElementById('course-content');

  // Obtém o parâmetro ?id= da URL
  const urlParams = new URLSearchParams(window.location.search);
  const courseId = urlParams.get('id');

  if (!courseId) {
    showError('Nenhum curso foi selecionado. Por favor, acerte a URL ou retorne ao catálogo.');
    return;
  }

  try {
    const course = await fetchCourseById(courseId);
    renderCourseDetails(course);
  } catch (err) {
    showError(err.message || 'Falha ao carregar informações do curso.');
  }

  function showError(msg) {
    loadingState.style.display = 'none';
    courseContent.style.display = 'none';
    errorState.style.display = 'block';
    errorMessage.textContent = msg;
    document.getElementById('breadcrumb-title').textContent = 'Curso não encontrado';
  }

  function renderCourseDetails(course) {
    loadingState.style.display = 'none';
    errorState.style.display = 'none';
    courseContent.style.display = 'block';

    // Atualiza metadados e título da página
    document.title = `${course.fullName} | SESI + Indústria`;
    document.getElementById('breadcrumb-title').textContent = course.fullName;

    // Hero do curso
    const cat = getCategoryInfo(course.category);
    const badgeEl = document.getElementById('detail-category-badge');
    badgeEl.className = `badge-category ${cat.badgeClass}`;
    document.getElementById('detail-category-icon').src = cat.icon;
    document.getElementById('detail-category-name').textContent = course.category;

    document.getElementById('detail-title').textContent = course.fullName;
    document.getElementById('detail-short-desc').textContent = course.description;
    document.getElementById('detail-workload').textContent = `${course.workloadHours} horas`;
    document.getElementById('detail-modality').textContent = course.modality;
    document.getElementById('detail-status').textContent = course.status;

    // Data de disponibilização
    let dateStr = 'Disponível imediatamente';
    if (course.availableDate) {
      try {
        const d = new Date(course.availableDate);
        dateStr = `Disponível a partir de ${d.toLocaleDateString('pt-BR')}`;
      } catch (e) {
        dateStr = course.availableDate;
      }
    }
    document.getElementById('detail-available-date').textContent = dateStr;

    // Imagem do curso
    let imgPath = course.imageUrl || 'assets/images/video-thumb.png';
    if (imgPath.startsWith('/')) imgPath = imgPath.substring(1);
    document.getElementById('detail-image').src = imgPath;
    document.getElementById('detail-image').alt = course.fullName;

    // Links para o AVA com o ID do curso
    const avaUrl = `ava.html?id=${course.id}`;
    document.getElementById('btn-hero-ava').href = avaUrl;
    document.getElementById('btn-fixed-ava').href = avaUrl;
    document.getElementById('nav-btn-ava').href = avaUrl;

    // Sobre o curso
    document.getElementById('detail-full-description').innerHTML = `
      <p>${course.description}</p>
      <p>Desenvolvido pelo Centro de Tecnologias e Educação Digital (CTED) do SESI-SP, este programa oferece capacitação alinhada com as melhores práticas de mercado e inovação tecnológica industrial.</p>
    `;
    document.getElementById('detail-target-audience').textContent = course.targetAudience || 'Profissionais e estudantes do setor industrial';

    // Barra fixa
    document.getElementById('fixed-title').textContent = course.fullName;
    document.getElementById('fixed-workload').textContent = `${course.workloadHours}h`;

    // Renderização dos Módulos e Aulas
    renderModules(course.modules);

    // Configuração dos Accordions
    setupAccordions();
  }

  function renderModules(modules) {
    const container = document.getElementById('modules-container');
    if (!modules || modules.length === 0) {
      container.innerHTML = '<p style="font-size: 13px; color: var(--color-text-muted);">Módulos em atualização pelo corpo docente.</p>';
      return;
    }

    container.innerHTML = modules.map((mod, idx) => {
      const lessonsHtml = (mod.lessons && mod.lessons.length > 0)
        ? `
          <ul class="lessons-list">
            ${mod.lessons.map(lesson => `
              <li class="lesson-item">
                <span>• ${lesson.title}</span>
                <span style="color: var(--color-text-muted); font-size: 12px;">${lesson.durationMinutes} min</span>
              </li>
            `).join('')}
          </ul>
        `
        : '<p style="font-size: 12px; color: var(--color-text-muted);">Aulas em processamento.</p>';

      return `
        <div class="module-card">
          <div class="module-title">Módulo ${idx + 1}: ${mod.title}</div>
          ${mod.description ? `<p style="font-size: 12px; color: var(--color-text-body); margin-bottom: 8px;">${mod.description}</p>` : ''}
          ${lessonsHtml}
        </div>
      `;
    }).join('');
  }

  function setupAccordions() {
    const accordions = document.querySelectorAll('.accordion-item');

    accordions.forEach(item => {
      const header = item.querySelector('.accordion-header');
      const body = item.querySelector('.accordion-body');
      const icon = item.querySelector('.acc-icon');

      header.addEventListener('click', () => {
        const isOpen = body.classList.contains('open');

        if (isOpen) {
          body.classList.remove('open');
          header.setAttribute('aria-expanded', 'false');
          if (icon) icon.textContent = '+';
        } else {
          body.classList.add('open');
          header.setAttribute('aria-expanded', 'true');
          if (icon) icon.textContent = '−';
        }
      });
    });
  }
});
